import type { Metadata } from 'next'
import type { ReactNode } from 'react'
import { DM_Sans, DM_Serif_Display } from 'next/font/google'
import './globals.css'
import { ToastContainer } from '@/components/ui'

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['300', '400', '500', '600'],
})

const dmSerif = DM_Serif_Display({
  subsets: ['latin'],
  variable: '--font-display',
  weight: '400',
  style: ['normal', 'italic'],
})

export const metadata: Metadata = {
  title: 'RecruitIQ — Belgium Market',
  description: 'Recruitment pipeline dashboard for the Belgium market',
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${dmSans.variable} ${dmSerif.variable}`}>
      <body>
        {children}
        <ToastContainer />
      </body>
    </html>
  )
}
