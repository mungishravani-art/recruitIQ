// ─────────────────────────────────────────
// lib/utils.ts — shared utility functions
// ─────────────────────────────────────────

/** Returns whole days since an ISO timestamp, or null if no timestamp provided. */
export function daysSince(iso: string | null | undefined): number | null {
  if (!iso) return null
  return Math.floor((Date.now() - new Date(iso).getTime()) / (1000 * 60 * 60 * 24))
}
