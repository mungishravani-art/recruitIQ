/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config, { isServer }) => {
    // pdfjs-dist tries to require 'canvas' for server-side rendering — it doesn't exist
    // in a Next.js environment. Ignore it so `next build` doesn't fail.
    config.resolve.alias.canvas = false

    // pdfjs-dist ships its own worker. Tell webpack not to try to bundle it —
    // we load it at runtime from the CDN in UploadModal.tsx.
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        path: false,
      }
    }

    return config
  },
}

module.exports = nextConfig
